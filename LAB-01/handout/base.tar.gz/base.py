import sys
import math


def calc_hipotenusa():



def calc_area_comprimento_circulo():



def calc_imc():



def calc_distancia_2pontos():

