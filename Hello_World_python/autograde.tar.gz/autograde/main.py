import sys

def hello_world():
    return 'Hello Worlds'

def hello_python():
    return 'Hello Python'

if __name__ == "__main__":
    world = hello_world()
    python = hello_python()